// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

/**
 * 
 */
class DESIGNPATTERNS_UE_API ElementData
{
public:
	ElementData();
	~ElementData();
};
