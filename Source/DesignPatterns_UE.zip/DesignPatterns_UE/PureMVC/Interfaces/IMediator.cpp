// Fill out your copyright notice in the Description page of Project Settings.


#include "IMediator.h"

// Add default functionality here for any IIMediator functions that are not pure virtual.
