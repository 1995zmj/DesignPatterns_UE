// Fill out your copyright notice in the Description page of Project Settings.


#include "INotification.h"

// Add default functionality here for any IINotification functions that are not pure virtual.
