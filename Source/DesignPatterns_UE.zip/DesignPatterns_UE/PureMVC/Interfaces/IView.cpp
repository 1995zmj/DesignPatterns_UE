// Fill out your copyright notice in the Description page of Project Settings.


#include "IView.h"

// Add default functionality here for any IIView functions that are not pure virtual.
