// Fill out your copyright notice in the Description page of Project Settings.


#include "ViewComponentInterface.h"

// Add default functionality here for any IViewComponentInterface functions that are not pure virtual.
void IViewComponentInterface::Init(UMediator* owner)
{
}
